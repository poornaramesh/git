package com.cognizant.model;

import javax.annotation.Generated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Table
@Data
public class Trainer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private String trainerid;
	private String password;
	
}

package com.spring.learn.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Country {

	private Logger logger = LoggerFactory.getLogger(Country.class);

	private String code;
	private String name;

	public Country() {
		logger.debug("Inside Country Constructor.");
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		logger.debug("Inside Code Property's Setter Method.");
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		logger.debug("Inside Name Property's Setter Method.");
		this.name = name;
	}

	@Override
	public String toString() {
		return "Country [code=" + code + ", name=" + name + "]";
	}


}

package com.cognizant.springlearn.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cognizant.springlearn.bean.Country;

@Component
public class CountryService {
	
	private static List<Country> country=new ArrayList<>();
	
	static {
		country.add(new Country("US","United States"));
		country.add(new Country("DE","Germany"));
		country.add(new Country("IN","India"));
		country.add(new Country("JP","Japan"));
	}
	
	public Country getIndia() {
		return country.get(2);
	}
	
	public List<Country> getAll() {
		return country;
	}
	
	public Country getCode(String code) {
		//System.out.println(code);
		for(Country c:country) {
			if(c.getCode().equalsIgnoreCase(code)) {
				return c;
			}
		}
		return null;
	}
}

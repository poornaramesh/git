package com.cognizant.springlearn.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.springlearn.bean.Country;
import com.cognizant.springlearn.service.CountryService;

@RestController
public class CountryController {
	
	@Autowired
	CountryService service;
	
	@RequestMapping(path="/country",method = RequestMethod.GET)
	public Country getCountryIndia() {
		return service.getIndia(); 
	}
	
	@GetMapping("/countries")
	public List<Country> getAllCountries() {
		return service.getAll();
	}
	
	@GetMapping("/countries/{code}")
	public Country getCountry(@PathVariable String code) {
		return service.getCode(code);
	}
}

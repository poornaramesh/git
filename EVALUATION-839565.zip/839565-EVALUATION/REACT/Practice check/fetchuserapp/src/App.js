import './App.css';
import GetUser from './components/GetUser';

function App() {
  return (
    <div className="App">
     <GetUser/>
     
    </div>
  );
}

export default App;
